
########Text mining########

## Install & load package
if(!require(rvest)) install.packages("rvest"); library(rvest)
if(!require(stringr)) install.packages("stringr"); library(stringr)
if(!require(XML)) install.packages("XML"); library(XML)
if(!require(KoNLP)) install.packages("KoNLP"); library(KoNLP)
if(!require(wordcloud)) install.packages("wordcloud"); library(wordcloud)
if(!require(RColorBrewer)) install.packages("RColorBrewer"); library(RColorBrewer)

#### Simple exercise
### Web crawling movie name from movie site(ex.lalaland)
url <- "http://movie.daum.net/moviedb/main?movieId=95306"
url_movie <- read_html(url)
movie_info <- html_nodes(url_movie, css='.tit_movie')
movie_info

movie_info[1] %>% html_text()

### Web crawling movie score from movie site(ex.lalaland)
url <- "http://movie.daum.net/moviedb/grade?movieId=95306"
url_movie <- read_html(url)
movie_score <- html_nodes(url_movie, css='.score_rating')
movie_score

movie_score[1] %>% html_text()

### Web crawling movie review from movie site(ex.lalaland)
url <- "http://movie.daum.net/moviedb/grade?movieId=95306&type=netizen&page=1"
url_movie <- read_html(url)
movie_review <- html_nodes(url_movie, css='.desc_review')
movie_review

movie_review[1] %>% html_text()
# \t : tab, \n : Enter

## Refine review data 
review1 <- movie_review[1] %>% html_text()
review1
review1 <- gsub("\n","", review1)
review1 <- gsub("\t","", review1)  
review1

## Refine all review data
review <- movie_review %>% html_text()
review
review <- gsub("\n","", review)
review <- gsub("\t","", review)
review <- gsub("\r","", review) # \r : Cursor to the top
review

### Web crawling movie next page review from movie movie site(ex.lalaland)
url <- "http://movie.daum.net/moviedb/grade?movieId=95306&type=netizen&page=2"
url_movie <- read_html(url)
movie_review <- html_nodes(url_movie, css='.desc_review')
movie_review

## Refine all review data
review <- movie_review %>% html_text()
review
review <- gsub("\n","", review)
review <- gsub("\t","", review)
review <- gsub("\r","", review) # \r : Cursor to the top
review <- str_trim(review) # Remove first & end space
review

### Web crawling movie 1~50page review from review page review(ex.lalaland)
All_review=c() # setting blank vector
for (i in 1:50){
  url <- paste0("http://movie.daum.net/moviedb/grade?movieId=95306&type=netizen&page=",i)
  url_movie <- read_html(url)
  movie_review <- html_nodes(url_movie, css='.desc_review')
  review <- movie_review %>% html_text()
  review <- gsub("\n","", review)
  review <- gsub("\t","", review)
  review <- gsub("\r","", review)
  review <- str_trim(review)
  All_review = c(All_review, review)
}

All_review
write.table(All_review, "All_review(lalaland).txt")

### Web crawling movie 1~50page review from review page review(ex.mammamia)
All_review2=c() # setting blank vector
for (i in 1:50){
  url <- paste0("http://movie.daum.net/moviedb/grade?movieId=43220&type=netizen&page=",i)
  url_movie <- read_html(url)
  movie_review <- html_nodes(url_movie, css='.desc_review')
  review <- movie_review %>% html_text()
  review <- gsub("\n","", review)
  review <- gsub("\t","", review)
  review <- gsub("\r","", review)
  review <- str_trim(review)
  All_review2 = c(All_review2, review)
}

All_review2
write.table(All_review2, "All_review(mammamia).txt")

#### text analysis
useSejongDic() #load & use Sejong dictionary

### extract Nouns
nouns = unlist(sapply(All_review, extractNoun, USE.NAMES=F))
nouns2 = unlist(sapply(All_review2, extractNoun, USE.NAMES=F))
head(nouns)
head(nouns2)

### Remove one characters
nouns = Filter(function(x){nchar(x)>=2 & 5>=nchar(x)},nouns)
nouns2 = Filter(function(x){nchar(x)>=2 & 5>=nchar(x)},nouns2)

### count nouns in data
word_count_lalaland <- table(nouns)
word_count_mammamia <- table(nouns2)
word_count_lalaland <- sort(word_count_lalaland, decreasing=T)
word_count_mammamia <- sort(word_count_mammamia, decreasing=T)
head(word_count_lalaland,10)
head(word_count_mammamia,10)



### Word cloud
palette <- brewer.pal(8, "Set2")
wordcloud(names(word_count_lalaland), freq=word_count_lalaland, scale=c(10,4), 
          rot.per=0.25, mirrandom.order=F, colors=palette, random.color=T)


